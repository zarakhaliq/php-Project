<?php

require __DIR__ . '/../vendor/autoload.php';

define('API_KEY', getenv('OPENCAGE_API_KEY'));
