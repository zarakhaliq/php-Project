
<html lang=en>
<head>
<meta charset="UTF-8">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script type="text/javascript">
//var result=0;
$(document).ready(function(){
    //$(".input").load("data.php");
        $.ajax({
        url:"data.php",
        method:'POST',
        data:{},
        dataType:'json',
        success:function(result, status){
            //JSON.parse(result);
           //console.log(result);
            //console.log(result.weatherObservations[0]);
            function Append (){
            for (i=0; i<result.length; i++){
            $('#lng').append(weatherObservations[0].lng);
            }}
            Append();
            
            //document.write(result);
            //$('#lng').val(result.weatherObservations[0].lng);
            //alert(JSON.stringify(result));
            //return result;
        }
    })

});
</script>
</head>

<body>
<table style="border: solid 1px black" id='table'>
<tr>
<th>Geonames</th>
</tr>
<tr>
    <th>lng</th>
    <th>observation</th>
    <th>ICAO</th>
    <th>clouds</th>
    <th>datetime</th>
    <th>temperature</th>
</tr>
<tr>
<td id="lng"> </td>
<td>hello </td>
<td>hello </td>
<td>hello </td>
<td>hello </td>
<td>hello </td>
</tr>
<tr>
<td >hello </td>
<td>hello </td>
<td>hello </td>
<td>hello </td>
<td>hello </td>
<td>hello </td>
</tr>
<tr>
<td>hello </td>
<td>hello </td>
<td>hello </td>
<td>hello </td>
<td>hello </td>
<td>hello </td>
</tr>
<tr>
<td>hello </td>
<td>hello </td>
<td>hello </td>
<td>hello </td>
<td>hello </td>
<td>hello </td>
</tr>

</table>

</body>


</html>

